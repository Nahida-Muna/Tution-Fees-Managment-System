-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2020 at 08:22 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paysystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `detail` text NOT NULL,
  `delete_status` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `branch`, `address`, `detail`, `delete_status`) VALUES
(1, 'Model Academy', 'Lamabazer', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '1'),
(2, 'WINGS Learning Centre', 'Dhanmondi', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '1'),
(3, 'Hexa\'s Amborkhana', 'Amborkhana', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '0'),
(4, 'Hexa\'s Zindabazer', 'Zindabazer', 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.', '0'),
(5, 'Hexa\'s Upashahar ', 'Upashahar, Sylhet', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '0'),
(6, 'Hexa\'s Borolekha', 'Borolekha', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '0'),
(7, 'Udbash', 'Zindabazer, Sylhet', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '0'),
(8, 'Hexa\'s Lamabazer', 'Lamabazer', 'dgbhasjkdhasjkdhasjk', '1'),
(9, 'Hexa\'s Lamabazer', 'Lamabazer', 'sometings', '1'),
(10, 'Hexa\'s Lamabazer', 'Lamabazer', 'Lamabazer', '1'),
(11, 'Hexa\'s Lamabazer', 'Juri', '', '1'),
(12, 'Hexa\'s Lamabazar', 'Lamabazar', 'jjjjjjjjkjiujj', '1'),
(13, 'Hexa\'s Lamabazar', 'Lamabazar', 'Something aaa', '1'),
(14, 'Hexa\'s Lamabazar', 'Lamabazar', 'Something ad', '1'),
(15, 'Hexa\'s Lamabazar', 'Lamabazar', 'Something abc', '1'),
(16, 'Hexa\'s Lamabazar', 'Lamabazar', 'Something abc', '1'),
(17, 'Hexa\'s Lamabazar', 'Lamabazar', 'Something abc', '1'),
(18, 'Hexa\'s Lamabazar', 'Lamabazar', 'Something abc', '1'),
(19, 'Hexa\'s Lamabazar', 'Lamabazar', 'Something abc', '1'),
(20, 'Hexa\'s Lamabazar', 'Lamabazae', 'Something abc', '1');

-- --------------------------------------------------------

--
-- Table structure for table `fees_transaction`
--

CREATE TABLE `fees_transaction` (
  `id` int(255) NOT NULL,
  `stdid` varchar(255) NOT NULL,
  `paid` int(255) NOT NULL,
  `submitdate` datetime NOT NULL,
  `transcation_remark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_transaction`
--

INSERT INTO `fees_transaction` (`id`, `stdid`, `paid`, `submitdate`, `transcation_remark`) VALUES
(1, '1', 100, '2017-11-01 00:00:00', ''),
(2, '2', 150, '2017-10-05 00:00:00', ''),
(3, '3', 900, '2017-04-13 00:00:00', 'monthly'),
(4, '3', 1000, '2018-04-01 00:00:00', 'lklk'),
(5, '4', 500, '2018-07-02 00:00:00', 'TEST'),
(6, '5', 1500, '2018-06-02 00:00:00', 'DEMO'),
(7, '6', 200, '2018-07-03 00:00:00', 'DEMO'),
(8, '7', 200, '2018-03-02 00:00:00', 'DEMO'),
(9, '8', 5000, '2017-01-03 00:00:00', 'DEMO'),
(10, '9', 2500, '2018-03-02 00:00:00', 'DEMO'),
(11, '10', 1000, '2019-10-18 00:00:00', ''),
(12, '10', 1000, '2020-10-30 00:00:00', ''),
(13, '11', 2000, '2019-10-11 00:00:00', ''),
(14, '12', 2000, '2019-10-14 00:00:00', ''),
(15, '13', 1200, '2019-08-22 00:00:00', ''),
(16, '14', 1000, '2020-08-20 00:00:00', ''),
(17, '15', 1800, '2020-10-14 00:00:00', ''),
(18, '16', 1200, '2020-10-27 00:00:00', ''),
(19, '17', 5000, '2020-10-28 00:00:00', ''),
(20, '18', 1000, '2020-10-09 00:00:00', ''),
(21, '19', 1200, '2020-10-08 00:00:00', ''),
(22, '20', 1500, '2020-11-12 00:00:00', 'Spoken English'),
(23, '21', 1600, '2020-11-01 00:00:00', 'Spoken English'),
(24, '11', 1000, '2019-10-11 00:00:00', ''),
(25, '22', 1600, '2020-11-01 00:00:00', 'Spoken English'),
(26, '12', 3000, '2019-10-14 00:00:00', ''),
(27, '21', 1400, '2020-11-01 00:00:00', ''),
(28, '23', 1600, '2020-11-01 00:00:00', 'Spoken English'),
(29, '23', 1400, '2020-11-01 00:00:00', ''),
(30, '24', 1600, '2020-11-01 00:00:00', 'Spoken English'),
(31, '24', 1400, '2020-11-01 00:00:00', ''),
(32, '25', 1600, '2020-11-01 00:00:00', 'Spoken English'),
(33, '26', 1600, '2020-11-01 00:00:00', 'Spoking English'),
(34, '27', 1600, '2020-11-01 00:00:00', 'Spoken English'),
(35, '26', 1400, '2020-11-01 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `joindate` datetime NOT NULL,
  `about` text NOT NULL,
  `contact` varchar(255) NOT NULL,
  `fees` int(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `balance` int(255) NOT NULL,
  `delete_status` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `emailid`, `sname`, `joindate`, `about`, `contact`, `fees`, `branch`, `balance`, `delete_status`) VALUES
(10, '', 'Abdur Rahim', '2019-10-18 00:00:00', '', '0179888777', 2000, '3', 0, '0'),
(11, 'a.alim@gmail.com', 'Abdul Alim', '2019-10-11 00:00:00', '', '0192234566', 3000, '7', 0, '0'),
(12, '', 'Priyanka Deb', '2019-10-14 00:00:00', '', '0164784739', 5000, '1', 0, '0'),
(13, '', 'Suktara', '2019-08-22 00:00:00', '', '0155773874', 3000, '6', 1800, '0'),
(14, '', 'Fahim', '2020-08-20 00:00:00', '', '0192918392', 3000, '4', 2000, '0'),
(15, '', 'Faisal', '2020-10-14 00:00:00', '', '0128910282', 3000, '3', 1200, '0'),
(16, '', 'Kosru', '2020-10-27 00:00:00', '', '0167823821', 3000, '4', 1800, '0'),
(17, '', 'Fokrul', '2020-10-28 00:00:00', '', '0198922323', 10000, '2', 5000, '0'),
(18, '', 'Sokina', '2020-10-09 00:00:00', '', '0178971238', 3000, '5', 2000, '0'),
(19, '', 'Adnan', '2020-10-08 00:00:00', '', '0192018390', 3000, '1', 1800, '0'),
(20, '', 'Iqbal', '2020-11-12 00:00:00', '', '0153556356', 3000, '4', 1500, '0'),
(21, '', 'Muna', '2020-11-01 00:00:00', '', '0145444242', 3000, '3', 0, '0'),
(22, '', 'Nahida', '2020-11-01 00:00:00', '', '0154535464', 3000, '3', 1400, '1'),
(23, '', 'nahida', '2020-11-01 00:00:00', '', '0174512783', 3000, '3', 0, '1'),
(24, '', 'Nahida', '2020-11-01 00:00:00', '', '0171245789', 3000, '3', 0, '1'),
(25, '', 'Nahida', '2020-11-01 00:00:00', '', '0171245789', 3000, '3', 1400, '1'),
(26, '', 'Nahida', '2020-11-01 00:00:00', '', '0171478523', 3000, '3', 0, '0'),
(27, '', 'Nahida', '2020-11-01 00:00:00', '', '0712457896', 3000, '3', 1400, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `lastlogin` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `emailid`, `lastlogin`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Lewa', 'lewa@gmail.com', '0000-00-00 00:00:00'),
(2, 'muna', 'e10adc3949ba59abbe56e057f20f883e', 'Muna', 'nahidamuna1994@gmail.com', '0000-00-00 00:00:00'),
(3, 'anamika', '21232f297a57a5a743894a0e4a801fc3', 'Anamika', 'anamika@gmail.com', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_transaction`
--
ALTER TABLE `fees_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `fees_transaction`
--
ALTER TABLE `fees_transaction`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
